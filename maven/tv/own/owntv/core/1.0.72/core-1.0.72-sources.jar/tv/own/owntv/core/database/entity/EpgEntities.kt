package tv.own.owntv.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import tv.own.owntv.core.parser.EpgDetails
import java.util.Objects

/**
 * EPG channel descriptor (XMLTV `<channel>` or an Xtream epg id). Channels link to it via their
 * `epgChannelId`.
 */
// NOTE: no foreign key to sources. EPG also comes from standalone EPG sources (stored in DataStore
// with negative ids that don't exist in the sources table), so a sourceId FK would reject them.
// EPG rows are cleared explicitly when a source/EPG-source is removed.
@Entity(
    tableName = "epg_channels",
    indices = [
        Index("sourceId"),
        Index(value = ["sourceId", "epgChannelId"], unique = true),
        Index("normName"),
    ],
)
data class EpgChannelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: Long,
    val epgChannelId: String,
    val displayName: String? = null,
    /** The feed's own `<icon src>` logo, used instead of the provider logo when the user turns
     *  Settings → EPG Sources → "Use this guide's channel logos" on for this feed. Null when the feed
     *  carries no usable icon. */
    val iconUrl: String? = null,
    /**
     * [displayName] and [epgChannelId] through `EpgMatcher.normalizeForEpg`, stored at sync time.
     *
     * The matcher normalizes both of these for every candidate, on every keystroke in the "Match EPG"
     * search and again for every run of auto-match — an NFKC pass plus four regex passes each, across
     * thousands of rows, recomputed to the same answer every time. The feed only changes when it is
     * synced, so this is computed there instead.
     *
     * **Both are nullable on purpose.** A row written before this existed, or by any path that has
     * not been taught to fill them, must degrade to normalizing on the fly rather than dropping the
     * channel out of the picker. Every reader treats null as "not known yet", never as "empty".
     */
    val normName: String? = null,
    val normId: String? = null,
)

/**
 * A single programme (now/next & guide). Bounded to a rolling window (≈ now → +48h) by the EPG
 * engine, which prunes old rows. Indexed on `(epgChannelId, startMs)` for fast now/next lookups.
 */
@Entity(
    tableName = "epg_programmes",
    indices = [
        Index(value = ["epgChannelId", "startMs"]),
        Index("stopMs"),
        // Time-bounded reads (a rail, an "on now" list) seek a range of start times rather than
        // walking the table. Without it a bounded window still examined every row in the database.
        Index(value = ["startMs", "stopMs"]),
        // Also serves every read by source, or by source and channel: no separate index for either
        // (v50 dropped both — each costs every guide write, on a TV several milliseconds a row).
        Index(value = ["sourceId", "epgChannelId", "startMs"], unique = true, name = "index_epg_programmes_natural_key"),
    ],
)
data class EpgProgrammeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: Long,
    val epgChannelId: String,
    val startMs: Long,
    val stopMs: Long,
    val title: String,
    val description: String? = null,
    @ColumnInfo(defaultValue = "0") val contentHash: Int = 0,
    // The details line (v47), from XMLTV only; null when the feed does not carry it.
    // See tv.own.owntv.core.parser.EpgDetails — [categories] is joined by its separator.
    val categories: String? = null,
    val year: Int? = null,
    val rating: String? = null,
    val lengthMin: Int? = null,
    val episode: String? = null,
) {
    val details: EpgDetails get() = EpgDetails(categories, year, rating, lengthMin, episode)
}

/** A programme row carrying the feed's [details]. */
fun EpgProgrammeEntity.withDetails(details: EpgDetails): EpgProgrammeEntity = if (details == EpgDetails.NONE) this else copy(
    categories = details.categories,
    year = details.year,
    rating = details.rating,
    lengthMin = details.lengthMin,
    episode = details.episode,
)

/** Projection for the "Use this guide's channel logos" override: one EPG channel id → its feed icon. */
data class EpgChannelIcon(
    val epgChannelId: String,
    val iconUrl: String,
)

/**
 * Projection for the "Match EPG" candidate list: one feed's name for one guide channel, with the
 * normalized forms the matcher works in. Both may be null on a row written before v41 or by a path
 * that does not fill them — the reader normalizes on the fly for those.
 */
data class EpgChannelName(
    val epgChannelId: String,
    val displayName: String?,
    val normName: String?,
    val normId: String?,
)

/**
 * A programme as the Sports hub's matcher reads it: what it is called and how the feed files it, never
 * its synopsis — see [tv.own.owntv.core.database.dao.EpgDao.sportsProgrammes].
 */
data class EpgProgrammeLite(
    val id: Long,
    val epgChannelId: String,
    val startMs: Long,
    val stopMs: Long,
    val title: String,
    val categories: String?,
)

/** One programme's synopsis, read only for the programmes the title alone did not match. */
data class EpgProgrammeText(val id: Long, val description: String?)

/** One programme's title, for the guide title search's case-folded pass — see [tv.own.owntv.core.database.dao.EpgDao.searchTitles]. */
data class EpgProgrammeTitle(val id: Long, val title: String)

data class EpgHashProjection(
    val id: Long,
    val epgChannelId: String,
    val startMs: Long,
    val contentHash: Int,
)

// The details are part of the hash, so a feed that starts sending them (or the first sync after v47)
// rewrites the rows instead of skipping them as unchanged.
fun EpgProgrammeEntity.computeContentHash(): Int =
    Objects.hash(title, description, stopMs, categories, year, rating, lengthMin, episode)
