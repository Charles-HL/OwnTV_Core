package tv.own.owntv.core.repository

import android.os.SystemClock
import android.util.Log
import androidx.room.execSQL
import androidx.room.immediateTransaction
import androidx.room.useReaderConnection
import androidx.room.useWriterConnection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import tv.own.owntv.core.CorePerf
import tv.own.owntv.core.database.BulkInsertHelper
import tv.own.owntv.core.customize.CustomizationStore
import tv.own.owntv.core.customize.SectionCustomizations
import tv.own.owntv.core.database.dao.ChannelDao
import tv.own.owntv.core.database.dao.EpgDao
import tv.own.owntv.core.model.MediaType
import tv.own.owntv.core.settings.SettingsRepository
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.EpgChannelEntity
import tv.own.owntv.core.epg.ArchiveGuidePlan
import tv.own.owntv.core.epg.EpgMatcher
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.database.entity.computeContentHash
import tv.own.owntv.core.database.entity.withDetails
import tv.own.owntv.core.epg.FeedDedupe
import tv.own.owntv.core.live.epgKeyOf
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient
import tv.own.owntv.core.parser.XmltvParser
import tv.own.owntv.core.parser.XtreamClient

/**
 * Fetches and stores the bulk XMLTV guide for a source (Xtream `xmltv.php`, or a M3U playlist's
 * `url-tvg`). Only programmes overlapping a rolling window are kept, and finished rows are pruned, so
 * the guide stays bounded. The grid reads from [EpgDao]; per-channel now/next still uses Xtream's
 * short-EPG separately.
 */
class EpgRepository(
    private val epgDao: EpgDao,
    private val http: HttpClient,
    private val xtream: XtreamClient,
    private val channelDao: ChannelDao,
    private val customize: CustomizationStore,
    private val settings: SettingsRepository,
    private val context: android.content.Context,
    private val db: tv.own.owntv.core.database.OwnTVDatabase,
    private val bulkInsertHelper: BulkInsertHelper,
    private val sourceDao: tv.own.owntv.core.database.dao.SourceDao,
    private val stalkerEpg: tv.own.owntv.core.stalker.StalkerEpgLoader,
) {

    /** Where a source's downloaded XMLTV is cached, so a later smart-match can top up programmes from it
     *  without re-hitting the network (see [storeProgrammesForIdsFromCache]). */
    private fun cacheFile(storeId: Long) = java.io.File(context.cacheDir, "epg_$storeId$EPG_CACHE_SUFFIX")

    /**
     * Where the download is tee'd *while it runs*. It only becomes [cacheFile] once the parse has
     * completed cleanly, so a guide truncated by a network drop is never left behind under the name
     * readers trust. The `.tmp` suffix also keeps it out of [storeProgrammesForIdsFromCache]'s
     * `endsWith(".xmltv")` scan while it's being written.
     */
    private fun tempCacheFile(storeId: Long) = java.io.File(context.cacheDir, "epg_$storeId$EPG_CACHE_TEMP_SUFFIX")

    /**
     * Drop temp caches abandoned by a killed process. Only files older than the cache TTL are touched:
     * a *fresh* `.tmp` may belong to another source syncing right now, and deleting it would silently
     * cost that sync its cache.
     */
    private fun sweepOrphanedTempCaches(now: Long) {
        runCatching {
            context.cacheDir.listFiles()
                ?.forEach { if (isOrphanedEpgTempCache(it.name, it.lastModified(), now, CACHE_TTL_MS)) it.delete() }
        }
    }

    /**
     * Ensure every non-unique `epg_programmes` index exists — the Guide read-index
     * `(sourceId, epgChannelId)` turns the "which channels have guide data" lookup from a
     * multi-second full scan into a fast index scan; the others are Room-declared and get dropped
     * by an eligible fresh EPG bulk import, so this pass must recreate ALL of them (the canonical
     * list is shared with BulkInsertHelper's restore and the migration heal — a missing index would
     * crash the next migration's schema validation). Indexes are **permanent** and
     * **auto-maintained** by SQLite, so this builds them exactly once (in the background) and is an
     * instant no-op every call after. Run at startup (for users who already have EPG) and after
     * each EPG sync (for brand-new EPG).
     */
    suspend fun ensureEpgIndexes() = withContext(Dispatchers.IO) {
        try {
            val startedAt = SystemClock.elapsedRealtime()
            db.useWriterConnection { connection ->
                tv.own.owntv.core.database.OwnTVDatabase.EXPECTED_NON_UNIQUE_INDEXES
                    .getValue("epg_programmes")
                    .forEach { connection.execSQL(it) }
            }
            Log.d("EpgRepository", "ensureEpgIndexes ms=${SystemClock.elapsedRealtime() - startedAt}")
        } catch (c: CancellationException) {
            throw c
        } catch (e: Exception) {
            Log.w("EpgRepository", "Unable to create EPG guide index", e)
        }
    }

    /**
     * The set of normalised EPG ids the user's channels actually reference: every channel's tvg-id plus
     * any persisted smart-match overrides. Public XMLTV feeds carry thousands of channels the user doesn't
     * have, so the bulk sync filters programmes to this set instead of storing the whole feed. Returns null
     * when we can't determine any ids (no channels / no tvg-ids) — caller then stores everything (never
     * filter the guide down to empty).
     */
    /**
     * How far forward the guide is stored, from the user's "Guide days to keep".
     *
     * Read per sync rather than cached, so changing the setting takes effect on the next refresh
     * without an app restart. One value feeds the sync window and the prune, so the two can never
     * disagree about what should be on disk.
     */
    private suspend fun guideAheadMs(): Long =
        settings.guideDaysToKeep.first().toLong() * 24 * 60 * 60 * 1000

    private suspend fun neededEpgIds(): Set<String>? {
        val ids = HashSet<String>()
        try {
            channelDao.allEpgChannelIds().forEach { ids.add(it) } // already lower+trim from SQL
        } catch (c: CancellationException) {
            throw c
        } catch (e: NoProgrammesInWindowException) {
            throw e
        } catch (e: Exception) {
            Log.w("EpgRepository", "Unable to read channel EPG ids — using unfiltered guide sync", e)
        }
        try {
            // EVERY profile's matches, not just the one that happens to be signed in. The sync filters
            // the feed down to this set, so reading only the active profile silently dropped every
            // other profile's hand-matched channels out of the download — their guide then emptied on
            // the next sync, and switching profile was the only way to notice.
            for (profile in db.profileDao().getAllOnce()) {
                customize.observe(profile.id, MediaType.LIVE).first().epgMatches.values
                    .forEach { ids.add(it.trim().lowercase()) }
            }
        } catch (c: CancellationException) {
            throw c
        } catch (e: Exception) {
            Log.w("EpgRepository", "Unable to read custom EPG matches — using unfiltered guide sync", e)
        }
        return ids.ifEmpty { null }
    }

    /**
     * The guide ids whose **past** is worth keeping: every catch-up channel's own id, plus whatever a
     * hand-made match points it at.
     *
     * The match half is the part that is easy to get wrong and expensive to get wrong. A matched
     * catch-up channel reads its guide under a *different* id from its own `epgChannelId`, so a prune
     * that consulted only the column would delete exactly the history that channel needs, and the
     * user would find their archive empty on the channels they had bothered to fix by hand. Every
     * profile's matches are consulted, for the same reason [neededEpgIds] consults them all.
     *
     * Resolved through [tv.own.owntv.core.customize.EpgMatchResolver], not the raw map, so a match
     * made before a playlist was deleted and re-added still protects its history.
     */
    internal suspend fun catchupGuideIds(): Set<String>? {
        val ids = HashSet<String>()
        val catchupChannels = runCatching { channelDao.allCatchupChannels() }.getOrElse {
            Log.w("EpgRepository", "Unable to read catch-up channels — keeping all history this run", it)
            return null
        }
        if (catchupChannels.isEmpty()) return emptySet()
        catchupChannels.forEach { ch ->
            ch.epgChannelId?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }?.let(ids::add)
        }
        try {
            for (profile in db.profileDao().getAllOnce()) {
                val resolver = customize.observe(profile.id, MediaType.LIVE).first().epgMatchResolver
                catchupChannels.forEach { ch ->
                    resolver.epgIdFor(ch)?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }?.let(ids::add)
                }
            }
        } catch (c: CancellationException) {
            throw c
        } catch (e: Exception) {
            // A hand-matched catch-up channel reads its guide under an id that is NOT its own column,
            // so without the matches this set is incomplete — and pruning against an incomplete set
            // deletes exactly the archive the user bothered to fix by hand. Decline to prune instead.
            Log.w("EpgRepository", "Unable to read EPG matches — keeping all history this run", e)
            return null
        }
        return ids
    }

    /**
     * Drop finished programmes, keeping a full archive **only for channels that can replay it**.
     *
     * Seven days of history used to be kept for every channel. On a 7,083-channel lineup where a few
     * hundred have catch-up, that is overwhelmingly history nobody can watch — and it is not free: it
     * inflates every scan, every DISTINCT, the ANALYZE, the backup, and the prune itself, which was
     * measured at 38.9 s of a 112 s sync on the maintainer's television.
     *
     * Everything else keeps [RECENT_PAST_MS], which is what the player overlay's "Before" slot and a
     * just-finished programme need, and nothing more.
     *
     * The keep-set goes into a temporary table rather than an `IN (...)` list: it can run to thousands
     * of ids, and SQLite rejects a statement with more than 999 bound parameters on older Android.
     */
    private suspend fun pruneFinishedProgrammes(now: Long) = withContext(Dispatchers.IO) {
        val archiveCutoff = now - WINDOW_BACK_MS
        val recentCutoff = now - RECENT_PAST_MS
        // Anything beyond the horizon the user asked for is dropped as well, so lowering "Guide days
        // to keep" actually frees the space rather than leaving orphaned rows the sync stops touching.
        runCatching { epgDao.pruneFuture(now + guideAheadMs()) }
            .onFailure { Log.w("EpgRepository", "Unable to prune beyond the guide horizon", it) }
        // Beyond the archive window nothing is replayable, whatever the channel is.
        epgDao.prune(archiveCutoff)

        val keep = catchupGuideIds()
        if (keep == null) {
            // Could not work out which channels can replay their past. Deleting on a guess would take
            // archives that cannot be re-downloaded, so this run keeps everything inside the archive
            // window and tries again on the next sync. Costs disk; cannot cost data.
            CorePerf.log { "epg_retention skipped=unknown-catchup archiveH=${WINDOW_BACK_MS / 3_600_000}" }
            return@withContext
        }
        if (keep.isEmpty()) {
            // No catch-up anywhere: nothing can replay anything, so keep only the recent past.
            epgDao.prune(recentCutoff)
            CorePerf.log { "epg_retention catchupIds=0 recentPastH=${RECENT_PAST_MS / 3_600_000}" }
            return@withContext
        }
        db.useWriterConnection { connection ->
            connection.execSQL("CREATE TEMP TABLE IF NOT EXISTS `epg_keep_history` (`epgChannelId` TEXT PRIMARY KEY NOT NULL)")
            connection.execSQL("DELETE FROM `epg_keep_history`")
            // Room's own transaction helper rather than hand-written BEGIN/COMMIT: this runs on a
            // pooled connection that Room may already have in a transaction, and immediateTransaction
            // handles the nesting.
            connection.immediateTransaction {
                usePrepared("INSERT OR IGNORE INTO `epg_keep_history` VALUES (?)") { statement ->
                    keep.forEach {
                        statement.clearBindings()
                        statement.bindText(1, it)
                        statement.step()
                        statement.reset()
                    }
                }
            }
            connection.usePrepared(
                "DELETE FROM `epg_programmes` WHERE `stopMs` < ? " +
                    "AND `epgChannelId` NOT IN (SELECT `epgChannelId` FROM `epg_keep_history`)",
            ) { statement ->
                statement.bindLong(1, recentCutoff)
                statement.step()
            }
            connection.execSQL("DROP TABLE IF EXISTS `epg_keep_history`")
        }
        CorePerf.log { "epg_retention catchupIds=${keep.size} recentPastH=${RECENT_PAST_MS / 3_600_000} archiveH=${WINDOW_BACK_MS / 3_600_000}" }
    }

    /**
     * Per guide id, the earliest stop time a sync accepts — [pruneFinishedProgrammes]' rule, applied
     * before writing instead of after. Unknown catch-up set: the whole window, as retention does.
     */
    private suspend fun pastCutoff(now: Long, archiveFrom: Long): (String) -> Long {
        val keep = catchupGuideIds() ?: return { archiveFrom }
        val recent = now - RECENT_PAST_MS
        return { key -> if (key in keep) archiveFrom else recent }
    }

    /** The guide URL for a source, or null if it has no EPG feed. A manual EPG URL always wins. */
    fun guideUrl(source: SourceEntity): String? = when (source.type) {
        SourceType.XTREAM -> source.epgUrl?.takeIf { it.isNotBlank() } ?: xtream.xmltvUrl(source)
        SourceType.M3U -> source.epgUrl?.takeIf { it.isNotBlank() }
        SourceType.LOCAL_BACKUP -> null
        // Stalker: user-pasted XMLTV, or the portal-advertised one adopted into epgUrl at sync
        // (StalkerSyncer.adoptPortalXmltvUrl) — and failing both, the portal's OWN
        // guide, addressed by the marker URL below — unless the user has switched that off for this
        // playlist. A portal that offers no XMLTV is the common case, and it used to mean no guide and
        // no catch-up at all.
        SourceType.STALKER -> source.epgUrl?.takeIf { it.isNotBlank() }
            ?: stalkerGuideUrl(source.id).takeIf { source.importPortalEpg }
    }

    /**
     * Every guide feed a source offers. An M3U header may advertise several XMLTV feeds in one
     * comma-separated `url-tvg` (a provider covering two countries, say), and the whole string used to
     * be stored — and requested — as one address, which can only 404. Splitting here rather than at
     * import means playlists that already stored a joined value are fixed without a migration.
     */
    fun guideUrls(source: SourceEntity): List<String> = splitGuideUrls(guideUrl(source))

    fun hasGuide(source: SourceEntity): Boolean = guideUrl(source) != null

    /**
     * Refresh one playlist source's guide (used by the one-time migration). Returns programmes written.
     * Only the first feed of a comma-separated header is synced *here*: everything stored under one id
     * is one feed's worth of guide, and a second download would prune the first one's programmes as
     * stale. The further feeds are registered as EPG sources of their own, each with its own id, and
     * refreshed through [refreshUrl] like any other feed.
     */
    suspend fun refresh(source: SourceEntity, onProgress: (channels: Int, programmes: Int) -> Unit = { _, _ -> }): Int {
        val url = guideUrls(source).firstOrNull() ?: return 0
        return refreshUrl(source.id, url, source.userAgent, onProgress)
    }

    /**
     * Download [url] (XMLTV, gzip-aware) into the guide tables keyed by [storeId], keeping only the
     * rolling window. Used for standalone EPG sources (negative ids). Throws on network/parse failure.
     */
    suspend fun refreshUrl(
        storeId: Long,
        url: String,
        userAgent: String?,
        onProgress: (channels: Int, programmes: Int) -> Unit = { _, _ -> },
    ): Int = withContext(Dispatchers.IO) {
        // A portal guide is not a download, so it cannot go through the XMLTV path below — but it is
        // stored, pruned, matched and read exactly like one, which is why it is addressed as a URL
        // and lives in the same EPG-source list with the same "sync now" button and error line.
        stalkerSourceIdOf(url)?.let { portalSourceId ->
            return@withContext refreshFromPortal(storeId, portalSourceId, onProgress)
        }
        val now = System.currentTimeMillis()
        val startedAt = SystemClock.elapsedRealtime()
        val from = now - WINDOW_BACK_MS
        val aheadMs = guideAheadMs()
        val to = now + aheadMs
        val globallyEmpty = bulkInsertHelper.tableIsEmpty("epg_programmes")
        val sourceEmpty = epgDao.countForSources(listOf(storeId)) == 0
        val freshSource = sourceEmpty

        // Filter programmes to the channels the user actually has (tvg-ids + persisted matches). Public
        // feeds carry far more channels than the user owns, so this is the single biggest sync speedup —
        // ~10–20× fewer rows. We still store ALL <channel> entries (cheap, needed as smart-match candidates).
        // Null = couldn't determine any ids → don't filter (never reduce the guide to empty).
        val needed = neededEpgIds()
        Log.d("EpgRepository", "EPG channel filter sourceId=$storeId ids=${needed?.size ?: 0} active=${needed != null}")
        val chunkSize = if (freshSource) BulkInsertHelper.CHUNK_FRESH else BulkInsertHelper.CHUNK
        val channels = LinkedHashMap<String, EpgChannelEntity>()
        val channelsWithProgrammes = HashSet<String>()
        val buffer = ArrayList<EpgProgrammeEntity>(chunkSize)
        // Per-channel, lazily-loaded and capped hash tracker: huge guides (millions of programme rows)
        // must never be mirrored into one giant in-memory map on a low-RAM TV box. Channels beyond the
        // cap degrade to write-through (REPLACE on the natural-key unique index keeps that correct).
        val hashTracker = ProgrammeHashTracker(epgDao, storeId, freshSource, MAX_TRACKED_PROGRAMMES)
        val preloadStartedAt = SystemClock.elapsedRealtime()
        hashTracker.preload(db)
        Log.d("EpgRepository", "EPG hash preload sourceId=$storeId ms=${SystemClock.elapsedRealtime() - preloadStartedAt}")
        var processedCount = 0
        var writtenCount = 0
        var inserted = 0
        var updated = 0
        var skipped = 0
        var parseCompleted = false
        var removedProgrammes = 0
        var removedChannels = 0
        // Timing trace: the download/parse and the DB writes are interleaved, so "write" is summed as
        // it happens and "parse" is what is left of the wall clock once it is taken out.
        var writeMs = 0L
        var pruneMs = 0L

        // Stream the feed: parse it as it downloads (no waiting for the whole file) while ALSO teeing the raw
        // bytes into a local cache file. The retained file lets a later smart-match top up just that channel's
        // programmes without another network round-trip — without slowing the live sync. The first
        // replacement batch is committed atomically so readers keep seeing the old guide until the new rows
        // are ready.
        // …tee'd to a temp name and promoted only on a clean parse: a truncated file would otherwise be
        // indistinguishable from a complete one for a full day, and a smart-match reading it would
        // conclude the missing channels simply have no schedule.
        val file = cacheFile(storeId)
        val tmpFile = tempCacheFile(storeId)
        sweepOrphanedTempCaches(now)
        suspend fun storeProgrammes(batch: List<EpgProgrammeEntity>) {
            if (batch.isEmpty()) return
            val startedAt = SystemClock.elapsedRealtime()
            writeProgrammes(batch)
            val batchMs = SystemClock.elapsedRealtime() - startedAt
            writeMs += batchMs
            Log.d(
                "EpgRepository",
                "EPG batch store sourceId=$storeId rows=${batch.size} writeMs=$batchMs",
            )
        }
        // One per sync: drops a feed's second copy of a programme before it is written (FeedDedupe).
        val feedDedupe = FeedDedupe()
        // The past is accepted only where retention would keep it: the recent past everywhere, the
        // whole archive window for catch-up channels. Accepting a week of history for every channel
        // and deleting it after the sync meant re-inserting all of it on every sync.
        val pastCutoffFor = pastCutoff(now, from)
        try {
            bulkInsertHelper.withOptimizedBulkInsert(
                "epg_programmes",
                ftsTable = null,
                eligible = globallyEmpty,
                ftsOnly = false,
            ) {
                tmpFile.outputStream().use { out ->
                    http.get(url, userAgent, maxAttempts = EPG_DOWNLOAD_ATTEMPTS) { input ->
                        XmltvParser.parse(
                            TeeInputStream(input, out),
                            onChannel = { id, name, icon ->
                                // Ids are stored normalized (trim+lowercase) so guide lookups can use the
                                // (epgChannelId, startMs) index directly — XMLTV ids often differ from the
                                // panel's epg_channel_id only in case.
                                val key = id.trim().lowercase()
                                channels.getOrPut(key) {
                                    // Normalized here, once per sync, instead of on every keystroke
                                    // of the "Match EPG" search and every auto-match run.
                                    EpgChannelEntity(
                                        sourceId = storeId,
                                        epgChannelId = key,
                                        displayName = name,
                                        iconUrl = icon,
                                        normName = name?.let(EpgMatcher::normalizeForEpg),
                                        normId = EpgMatcher.normalizeForEpg(key),
                                    )
                                }
                            },
                            onProgramme = { channelId, startMs, stopMs, title, desc, details ->
                                val key = channelId.trim().lowercase()
                                if (stopMs > pastCutoffFor(key) && startMs < to && (needed == null || key in needed) &&
                                    feedDedupe.accept(key, startMs, stopMs, title)
                                ) {
                                    channelsWithProgrammes.add(key)
                                    val programme = EpgProgrammeEntity(
                                        sourceId = storeId,
                                        epgChannelId = key,
                                        startMs = startMs,
                                        stopMs = stopMs,
                                        title = title,
                                        description = desc,
                                    ).withDetails(details)
                                    val hash = programme.computeContentHash()
                                    when (val decision = hashTracker.observe(key, startMs, hash)) {
                                        is ProgrammeDecision.New -> {
                                            buffer.add(programme.copy(contentHash = hash))
                                            inserted++
                                        }
                                        is ProgrammeDecision.Changed -> {
                                            buffer.add(programme.copy(id = decision.id, contentHash = hash))
                                            updated++
                                        }
                                        ProgrammeDecision.Unchanged -> skipped++
                                        // Over the memory cap (or duplicate-in-feed fallback): write through —
                                        // the unique (sourceId, epgChannelId, startMs) index + REPLACE dedupe.
                                        ProgrammeDecision.WriteThrough -> {
                                            buffer.add(programme.copy(contentHash = hash))
                                            inserted++
                                        }
                                    }
                                    processedCount++
                                    if (buffer.size >= chunkSize) {
                                        val batchSize = buffer.size
                                        storeProgrammes(buffer.toList())
                                        writtenCount += batchSize
                                        buffer.clear()
                                        onProgress(channelsWithProgrammes.size, processedCount)
                                    } else if (processedCount == 1 || processedCount % PROGRESS_PROGRAMME_STEP == 0) {
                                        onProgress(channelsWithProgrammes.size, processedCount)
                                    }
                                }
                            },
                            channelFilter = needed,
                        )
                    }
                }
                if (buffer.isNotEmpty()) {
                    val batchSize = buffer.size
                    storeProgrammes(buffer.toList())
                    writtenCount += batchSize
                    buffer.clear()
                }
                if (channels.isNotEmpty()) {
                    val channelsStartedAt = SystemClock.elapsedRealtime()
                    epgDao.upsertChannels(channels.values.toList())
                    val channelsMs = SystemClock.elapsedRealtime() - channelsStartedAt
                    writeMs += channelsMs
                    Log.d(
                        "EpgRepository",
                        "EPG channels store sourceId=$storeId rows=${channels.size} ms=$channelsMs",
                    )
                }
                parseCompleted = true
            }
            if (parseCompleted && channels.isNotEmpty() && processedCount == 0) {
                // Filtered to the playlists' channels and none of the feed's is one of them: the guide
                // has programmes, just for channels no playlist links to yet.
                if (needed != null && channels.keys.none { it in needed }) throw GuideMatchesNoChannelException()
                throw NoProgrammesInWindowException()
            }
        } catch (c: CancellationException) {
            throw c
        } catch (e: NoProgrammesInWindowException) {
            throw e
        } catch (e: Exception) {
            // Network drop or an unrecoverable parse position. Keep whatever we already pulled — a partial
            // guide beats none — and only fail outright if we got nothing at all.
            if (writtenCount == 0 && buffer.isEmpty() && channels.isEmpty()) throw e
            if (buffer.isNotEmpty()) {
                val batchSize = buffer.size
                storeProgrammes(buffer.toList())
                writtenCount += batchSize
                buffer.clear()
            }
            if (channels.isNotEmpty()) {
                val channelsStartedAt = SystemClock.elapsedRealtime()
                epgDao.upsertChannels(channels.values.toList())
                val channelsMs = SystemClock.elapsedRealtime() - channelsStartedAt
                writeMs += channelsMs
                Log.d(
                    "EpgRepository",
                    "EPG channels store sourceId=$storeId rows=${channels.size} ms=$channelsMs",
                )
            }
            Log.w("EpgRepository", "EPG sync incomplete — keeping partial (written=$writtenCount accepted=$processedCount inserted=$inserted updated=$updated skipped=$skipped)", e)
        } finally {
            // The rows already written stay (a partial guide still beats none) — only the *cache file*
            // is held to a completeness bar, because unlike the rows it gets re-read later as if it were
            // the whole feed. Anything short of a clean parse leaves the previous good cache in place.
            if (parseCompleted && tmpFile.length() > 0) {
                if (!(file.delete() || !file.exists()) || !tmpFile.renameTo(file)) {
                    Log.w("EpgRepository", "EPG cache promote failed storeId=$storeId — cache skipped this run")
                }
            }
            if (tmpFile.exists()) tmpFile.delete() // no-op after a successful rename
        }
        // Everything above is download + parse + the writes interleaved with it; everything below is
        // retention. Splitting the wall clock here is what makes parseMs and pruneMs mean something.
        val parsedAt = SystemClock.elapsedRealtime()
        if (parseCompleted) {
            removedProgrammes = pruneRemovedProgrammes(storeId, hashTracker)
            removedChannels = pruneRemovedChannels(storeId, channels.keys)
        }
        val pruneStartedAt = SystemClock.elapsedRealtime()
        pruneFinishedProgrammes(now)
        Log.d("EpgRepository", "EPG prune sourceId=$storeId ms=${SystemClock.elapsedRealtime() - pruneStartedAt}")
        // No collapse after the sync any more. Deleting one feed's copy of a programme another feed also
        // carries made it "missing" to that feed's next sync, which wrote it again — every row, every
        // sync. Copies inside one feed are now dropped while reading (FeedDedupe); copies across feeds
        // are left for EpgDedupe, which hides them on read as it always has.
        pruneMs = SystemClock.elapsedRealtime() - parsedAt
        ensureEpgIndexes() // new/refreshed EPG → make sure the Guide read-index exists (no-op if already there)
        val analyzeStartedAt = SystemClock.elapsedRealtime()
        runCatching { bulkInsertHelper.analyzeTables("epg_programmes", "epg_channels") }
            .onSuccess {
                Log.d("EpgRepository", "EPG analyze sourceId=$storeId ms=${SystemClock.elapsedRealtime() - analyzeStartedAt}")
            }
            .onFailure { Log.w("EpgRepository", "Unable to analyze EPG tables", it) }
        onProgress(channelsWithProgrammes.size, processedCount)
        Log.i(
            "EpgRepository",
            "EPG incremental sync sourceId=$storeId inserted=$inserted updated=$updated skipped=$skipped removedProgrammes=$removedProgrammes removedChannels=$removedChannels " +
                "accepted=$processedCount written=$writtenCount ms=${SystemClock.elapsedRealtime() - startedAt}",
        )
        CorePerf.log {
            val totalMs = SystemClock.elapsedRealtime() - startedAt
            "epg_sync sourceId=$storeId fresh=$freshSource filteredIds=${needed?.size ?: -1} " +
                "channelsIn=${channels.size} accepted=$processedCount written=$writtenCount " +
                "inserted=$inserted updated=$updated skipped=$skipped " +
                "removedProgrammes=$removedProgrammes removedChannels=$removedChannels " +
                "windowBackH=${WINDOW_BACK_MS / 3_600_000} windowAheadH=${aheadMs / 3_600_000} " +
                "parseMs=${parsedAt - startedAt - writeMs} writeMs=$writeMs pruneMs=$pruneMs " +
                "analyzeMs=${totalMs - (parsedAt - startedAt) - pruneMs} totalMs=$totalMs"
        }
        writtenCount
    }

    /**
     * Crawl a Stalker portal's own guide into the tables keyed by [storeId] (bulk `get_epg_info`
     * is still never used). Written in batches as it parses, so the payload is never
     * held; rows are keyed by the portal's channel id, which is what `StalkerSyncer` gives a portal
     * channel that has no XMLTV id of its own.
     *
     * A failed crawl throws with the guide left as it was. A crawl that returns nothing throws
     * [NoProgrammesInWindowException], the same answer the XMLTV path gives for a feed that carries
     * no programmes we can use — the apps already explain that one.
     */
    private suspend fun refreshFromPortal(
        storeId: Long,
        portalSourceId: Long,
        onProgress: (channels: Int, programmes: Int) -> Unit,
    ): Int {
        val startedAt = SystemClock.elapsedRealtime()
        val source = sourceDao.getById(portalSourceId)
            ?: throw PortalGuideSourceGoneException(portalSourceId)
        val now = System.currentTimeMillis()
        val from = now - WINDOW_BACK_MS
        val to = now + guideAheadMs()
        var written = 0
        val channels = LinkedHashSet<String>()
        // The portal keys its guide by its OWN channel id, but a channel that came with an `xmltv_id`
        // is stored under that instead — so the two disagree on exactly the channels most likely to
        // have a guide. Translate every row into the key its channel is actually stored under; a
        // portal id with no channel of its own keeps the portal id, which is what the fallback in
        // StalkerSyncer gives those channels anyway.
        val guideKeys = channelDao.guideKeysForSource(portalSourceId)
            .associate { it.remoteId.trim().lowercase() to it.epgChannelId.trim().lowercase() }
        val channelIds = channelDao.remoteIdsForSource(portalSourceId)
        val outcome = stalkerEpg.crawl(
            source = source,
            from = from,
            to = to,
            cacheDir = context.cacheDir,
            channelIds = channelIds,
            // Straight through to the EPG screen, so a portal guide counts up like any other feed
            // instead of sitting on "Connecting…" until it finishes.
            onProgress = { seenChannels, programmes -> onProgress(seenChannels, programmes) },
        ) { batch ->
            writeProgrammes(
                batch.map {
                    EpgProgrammeEntity(
                        sourceId = storeId,
                        epgChannelId = guideKeys[it.epgChannelId] ?: it.epgChannelId,
                        startMs = it.startMs,
                        stopMs = it.stopMs,
                        title = it.title,
                        description = it.description,
                    )
                },
            )
            written += batch.size
            batch.forEach { channels.add(guideKeys[it.epgChannelId] ?: it.epgChannelId) }
        }
        if (outcome.programmes == 0) throw NoProgrammesInWindowException()
        // A guide channel row per channel we saw, so the EPG matcher and the "guide channels" counts
        // treat a portal guide like any other. The portal's EPG payload carries no display name, so
        // the id doubles as the label — the matcher keys on the id regardless.
        epgDao.upsertChannels(
            channels.map {
                EpgChannelEntity(
                    sourceId = storeId,
                    epgChannelId = it,
                    displayName = it,
                    iconUrl = null,
                    normName = EpgMatcher.normalizeForEpg(it),
                    normId = EpgMatcher.normalizeForEpg(it),
                )
            },
        )
        // Programmes this crawl did not replace and the window no longer covers. The portal is the
        // whole truth for this store, so anything outside the window it just served is stale.
        epgDao.pruneOutsideWindow(storeId, from, to)
        pruneFinishedProgrammes(now)
        ensureEpgIndexes()
        runCatching { bulkInsertHelper.analyzeTables("epg_programmes", "epg_channels") }
            .onFailure { Log.w("EpgRepository", "Unable to analyze EPG tables", it) }
        onProgress(channels.size, written)
        Log.i(
            "EpgRepository",
            "EPG portal sync storeId=$storeId portalSourceId=$portalSourceId method=${outcome.method} " +
                "period=${outcome.periodDays} channels=${channels.size} written=$written " +
                "ms=${SystemClock.elapsedRealtime() - startedAt}",
        )
        return written
    }

    /**
     * The feed downloaded and parsed in full, and carried no programme for the days we keep.
     *
     * A definitive answer, not a failure: the server did everything right, so repeating the request
     * produces the same nothing. See [tv.own.owntv.core.sync.work.shouldRetryEpgSync].
     *
     * The message is a stable English comparison key, not user-facing wording — it is stored per
     * source and classified for display by [tv.own.owntv.core.util.classifySyncFailure]. It used to
     * have none at all, which left the EPG screen with nothing to show and the row reading "Not
     * synced yet" as though the sync had never run.
     */
    open class NoProgrammesInWindowException(
        message: String = "Guide has no programmes in the guide window",
    ) : java.io.IOException(message)

    /**
     * The feed carried channels, but not one of them is a channel the playlists use (by tvg-id or a
     * saved match), so the sync kept none of its programmes. Not an empty guide: Auto-match pairs the
     * channels by name, and the next sync keeps theirs. Still definitive, like its parent — syncing
     * again unchanged gives the same answer. The message is a stable comparison key, as above.
     */
    class GuideMatchesNoChannelException :
        NoProgrammesInWindowException("Guide channels match no playlist channel")

    /**
     * A portal guide whose playlist has since been deleted. Definitive for the same reason — the
     * row it points at is gone, and waiting does not bring it back.
     */
    class PortalGuideSourceGoneException(portalSourceId: Long) :
        java.io.IOException("Portal guide source $portalSourceId no longer exists")

    /**
     * Writes [batch] in one plain transaction through one statement, rather than the DAO's insert inside
     * [tv.own.owntv.core.database.transaction]: that nests Room's own transaction as a SAVEPOINT, and the
     * bundled SQLite then re-walks the savepoint's whole in-memory journal after every row — 7 ms a row on
     * a TV for a 10,000-row batch, against microseconds without it. Same SQL as the generated insert.
     */
    private suspend fun writeProgrammes(batch: List<EpgProgrammeEntity>) {
        db.useWriterConnection { connection ->
            connection.immediateTransaction {
                usePrepared(UPSERT_PROGRAMME_SQL) { statement ->
                    for (p in batch) {
                        statement.bindLong(1, p.id)
                        statement.bindLong(2, p.sourceId)
                        statement.bindText(3, p.epgChannelId)
                        statement.bindLong(4, p.startMs)
                        statement.bindLong(5, p.stopMs)
                        statement.bindText(6, p.title)
                        p.description?.let { statement.bindText(7, it) } ?: statement.bindNull(7)
                        statement.bindLong(8, p.contentHash.toLong())
                        p.categories?.let { statement.bindText(9, it) } ?: statement.bindNull(9)
                        p.year?.let { statement.bindLong(10, it.toLong()) } ?: statement.bindNull(10)
                        p.rating?.let { statement.bindText(11, it) } ?: statement.bindNull(11)
                        p.lengthMin?.let { statement.bindLong(12, it.toLong()) } ?: statement.bindNull(12)
                        p.episode?.let { statement.bindText(13, it) } ?: statement.bindNull(13)
                        statement.step()
                        statement.reset()
                    }
                }
            }
        }
    }

    private suspend fun pruneRemovedProgrammes(sourceId: Long, tracker: ProgrammeHashTracker): Int {
        val startedAt = SystemClock.elapsedRealtime()
        val staleIds = tracker.staleTrackedIds()
        staleIds.chunked(QUERY_CHUNK).forEach { epgDao.deleteProgrammesByIds(it) }
        Log.d("EpgRepository", "EPG programme prune sourceId=$sourceId stale=${staleIds.size} overflowed=${tracker.overflowed} ms=${SystemClock.elapsedRealtime() - startedAt}")
        return staleIds.size
    }

    private suspend fun pruneRemovedChannels(sourceId: Long, seenChannelIds: Set<String>): Int {
        val startedAt = SystemClock.elapsedRealtime()
        val existingChannelIds = epgDao.epgChannelIdsForSource(sourceId)
        val staleIds = if (seenChannelIds.isEmpty()) {
            if (existingChannelIds.isNotEmpty()) {
                epgDao.clearChannelsForSource(sourceId)
                epgDao.clearSource(sourceId)
            }
            existingChannelIds
        } else {
            existingChannelIds.filterNot(seenChannelIds::contains).also { stale ->
                stale.chunked(QUERY_CHUNK).forEach {
                    epgDao.deleteChannelsByEpgIds(sourceId, it)
                    // The per-channel hash tracker never loads channels absent from the feed, so
                    // their leftover programmes must be dropped here rather than by the id prune.
                    epgDao.deleteProgrammesForChannels(sourceId, it)
                }
            }
        }
        Log.d("EpgRepository", "EPG channel prune sourceId=$sourceId stale=${staleIds.size} ms=${SystemClock.elapsedRealtime() - startedAt}")
        return staleIds.size
    }

    /**
     * Top up programmes for newly-matched [epgIds] from the **cached** XMLTV file(s) — no network. Used right
     * after a smart-match so the channels' guide fills in instantly (the bulk sync filters to the channels you
     * have, so a freshly-matched id wasn't stored). Parses each cache file ONCE for the whole id set. Returns
     * false if there's no fresh (≤24h) cache to read — the caller then does a full network re-sync.
     */
    suspend fun storeProgrammesForIdsFromCache(epgIds: Set<String>): Boolean {
        val keys = epgIds.map { it.trim().lowercase() }.filterTo(HashSet()) { it.isNotBlank() }
        return keys.isEmpty() || fillFromCache(keys).isNotEmpty()
    }

    /**
     * [storeProgrammesForIdsFromCache] for normalized [keys], returning the ids the cache actually gave
     * programmes for — empty when there is no fresh cache or it carries none of them.
     */
    internal suspend fun fillFromCache(keys: Set<String>): Set<String> = withContext(Dispatchers.IO) {
        if (keys.isEmpty()) return@withContext emptySet()
        val now = System.currentTimeMillis()
        val from = now - WINDOW_BACK_MS; val to = now + guideAheadMs()
        val pastCutoffFor = pastCutoff(now, from)
        // Only promoted (complete) caches are eligible — an in-flight or abandoned `.xmltv.tmp` is
        // excluded by name, so a truncated download can't be mistaken for the whole feed.
        val files = context.cacheDir.listFiles()
            ?.filter { isUsableEpgCache(it.name, it.length(), it.lastModified(), now, CACHE_TTL_MS) }
            ?: emptyList<java.io.File>()
        if (files.isEmpty()) return@withContext emptySet() // no fresh cache → the caller falls back to a network re-sync
        Log.d("EpgRepository", "Cached EPG channel filter ids=${keys.size} files=${files.size}")

        val storeFiles = files.mapNotNull { f ->
            epgCacheStoreId(f.name)?.let { it to f }
        }
        val storeIds = storeFiles.map { it.first }
        val collected = HashMap<String, MutableList<EpgProgrammeEntity>>()
        for ((storeId, file) in storeFiles) {
            var foundHere = 0
            val feedDedupe = FeedDedupe()
            runCatching {
                file.inputStream().use { input ->
                    XmltvParser.parse(
                        input,
                        onChannel = { _, _, _ -> },
                        onProgramme = { channelId, startMs, stopMs, title, desc, details ->
                            val key = channelId.trim().lowercase()
                            if (key in keys && stopMs > pastCutoffFor(key) && startMs < to && feedDedupe.accept(key, startMs, stopMs, title)) {
                                collected.getOrPut(key) { ArrayList() }
                                    .add(EpgProgrammeEntity(sourceId = storeId, epgChannelId = key, startMs = startMs, stopMs = stopMs, title = title, description = desc).withDetails(details))
                                foundHere++
                            }
                        },
                        channelFilter = keys,
                    )
                }
            }.onFailure { Log.w("EpgRepository", "cacheFill parse failed storeId=$storeId (other sources unaffected)", it) }
        }

        val filled = HashSet<String>()
        for ((key, rows) in collected) {
            if (rows.isEmpty()) continue
            epgDao.clearChannelForSources(key, storeIds)
            rows.chunked(QUERY_CHUNK).forEach { epgDao.upsertProgrammes(it) }
            filled += key
        }
        // Only the ids the cache actually yielded programmes for count as handled. A fresh cache that
        // contains none of them (stale file, or a channel whose programmes weren't in the earlier tee'd
        // download) must fall through to a network re-sync — the match is now persisted, so the
        // re-sync's channel filter includes it and will fetch the missing schedule. Reporting those as
        // handled used to leave a just-matched channel permanently empty with no fallback.
        filled
    }

    /**
     * Fill guide gaps left by a catalog sync that finished after the guide sync started.
     *
     * [refreshUrl] filters the feed down to the channels the user owns, and reads that set **once**,
     * at the start. Sync a playlist and a guide at the same time and every channel the playlist
     * hadn't written yet is treated as "not mine" and skipped — the sync still reports success, and
     * the missing programmes stay missing until the user happens to re-sync EPG. (Observed: a guide
     * synced alongside a Stalker import stored 130k programmes; the same feed re-synced afterwards
     * stored 220k.) The same hole opens whenever a later resync adds channels.
     *
     * This runs after a catalog sync and repairs it **from the cached feed — no network**. Only
     * channels with no guide data at all are considered, so a normal resync finds nothing and does no
     * work beyond one indexed query. Returns the number of channels it filled.
     *
     * Deliberately never starts a download: EPG is opt-in, and no cache means the user hasn't synced
     * a guide for this feed yet.
     */
    suspend fun fillGuideGapsForSource(sourceId: Long): Int = withContext(Dispatchers.IO) {
        // Nothing to repair before the user has ever synced a guide — and without this the query
        // below would return every channel the source has.
        if (bulkInsertHelper.tableIsEmpty("epg_programmes")) return@withContext 0
        val missing = channelDao.epgChannelIdsWithoutProgrammes(sourceId)
            .filterTo(HashSet()) { it.isNotBlank() }
        if (missing.isEmpty()) return@withContext 0

        // Most channels without guide data are not a gap at all — their tvg-id simply isn't in any
        // feed the user subscribes to (observed in the field: 760 of 11,527). Parsing the whole
        // cached XMLTV for those takes ~14s and will never find anything, so don't repeat an attempt
        // that already came up empty against the same missing set and the same cache files. Held in
        // memory only: one wasted pass per process is a fair price for never persisting a decision
        // that could go stale.
        val fingerprint = "${missing.size}|${missing.hashCode()}|${cacheFingerprint()}"
        if (futileGapFills[sourceId] == fingerprint) {
            Log.d("EpgRepository", "guide gap fill sourceId=$sourceId skipped — same gap and same cache as the last empty attempt")
            return@withContext 0
        }
        Log.i("EpgRepository", "guide gap fill sourceId=$sourceId channelsWithoutProgrammes=${missing.size}")
        val filled = runCatching { storeProgrammesForIdsFromCache(missing) }
            .onFailure { Log.w("EpgRepository", "guide gap fill failed sourceId=$sourceId", it) }
            .getOrDefault(false)
        // A false return means no fresh cache, or the cache genuinely carries nothing for these ids
        // (they may simply not be in this feed) — either way there is nothing more to do offline.
        val remaining = if (filled) channelDao.epgChannelIdsWithoutProgrammes(sourceId).size else missing.size
        val repaired = (missing.size - remaining).coerceAtLeast(0)
        Log.i("EpgRepository", "guide gap fill done sourceId=$sourceId repaired=$repaired stillMissing=$remaining")
        if (repaired == 0) futileGapFills[sourceId] = fingerprint else futileGapFills.remove(sourceId)
        repaired
    }

    /** Per-source fingerprint of the last gap fill that found nothing — see [fillGuideGapsForSource]. */
    private val futileGapFills = java.util.concurrent.ConcurrentHashMap<Long, String>()

    /** When each channel's archive schedule was last asked for — see [fillArchiveGuide]. Memory only. */
    private val archiveTries = java.util.concurrent.ConcurrentHashMap<Long, Long>()

    // Room for a whole queue of fills (ArchiveGuideFiller), so a slow collector misses no channel.
    private val _archiveGuideAdded = MutableSharedFlow<Long>(extraBufferCapacity = 32)

    /** Ids of channels whose past programmes [fillArchiveGuide] just changed, so an open guide can re-read them. */
    internal val archiveGuideAdded: SharedFlow<Long> = _archiveGuideAdded.asSharedFlow()

    /**
     * Add the past of a catch-up Xtream [channel] that its guide feed does not carry, from the
     * provider's own schedule of that channel ([XtreamClient.getArchiveSchedule]).
     *
     * Many `xmltv.php` feeds stop about a day back while the archive keeps up to a week, so most of
     * what catch-up could replay never shows in the guide. One API call for one channel, at most once
     * every few hours per channel ([ArchiveGuidePlan]). The rows only fill the finished stretches the
     * feeds' own rows leave empty, and are stored under a guide store of their own ([ArchiveGuidePlan.storeId]): not
     * the playlist's id, whose guide sync would delete them as missing from its feed. Being no EPG
     * source, that store ranks below all of them ([tv.own.owntv.core.epg.GuidePriority]). Each fill
     * replaces the channel's rows there as a whole. Retention keeps them, as the past of every
     * catch-up channel is kept.
     *
     * Returns how many programmes the channel now has from its archive when they changed, 0 when
     * they did not (or the request failed), and null when the provider was not asked at all (not a
     * catch-up Xtream channel, or asked too recently), so a caller pacing its requests can skip ahead.
     */
    internal suspend fun fillArchiveGuide(channel: ChannelEntity, cust: SectionCustomizations): Int? = withContext(Dispatchers.IO) {
        if (!channel.catchup) return@withContext null
        val streamId = channel.remoteId?.takeIf { it.isNotBlank() } ?: return@withContext null
        // Trimmed and lower-cased, the way the guide stores and reads its ids.
        val key = epgKeyOf(channel, cust) ?: return@withContext null
        val now = System.currentTimeMillis()
        synchronized(archiveTries) {
            if (!ArchiveGuidePlan.due(archiveTries[channel.id], now)) return@withContext null
            archiveTries[channel.id] = now
        }
        val stored = try {
            val source = sourceDao.getById(channel.sourceId)?.takeIf { it.type == SourceType.XTREAM }
                ?: return@withContext null
            val listings = xtream.getArchiveSchedule(source, streamId)
            val from = ArchiveGuidePlan.windowStart(now, channel.catchupDays, WINDOW_BACK_MS)
            val store = ArchiveGuidePlan.storeId(channel.sourceId)
            val (own, feeds) = epgDao.programmeSummariesForChannel(key, from, Long.MAX_VALUE)
                .partition { it.sourceId == store }
            val keep = ArchiveGuidePlan.toStore(
                listings,
                feedRows = feeds.map { it.startMs to it.stopMs },
                windowStartMs = from,
                nowMs = now,
            )
            val changed = ArchiveGuidePlan.changed(keep, own.map { it.startMs })
            if (changed) {
                own.map { it.id }.chunked(QUERY_CHUNK).forEach { epgDao.deleteProgrammesByIds(it) }
                writeProgrammes(
                    keep.map {
                        EpgProgrammeEntity(
                            sourceId = store,
                            epgChannelId = key,
                            startMs = it.startMs,
                            stopMs = it.stopMs,
                            title = it.title,
                            description = it.description,
                        ).let { p -> p.copy(contentHash = p.computeContentHash()) }
                    },
                )
            }
            Log.i("EpgRepository", "archive guide channelId=${channel.id} listed=${listings.size} kept=${keep.size} changed=$changed")
            if (changed) _archiveGuideAdded.tryEmit(channel.id)
            if (changed) keep.size else 0
        } catch (c: CancellationException) {
            throw c
        } catch (e: Exception) {
            // A provider that hiccuped is asked again sooner than one that answered.
            archiveTries[channel.id] = ArchiveGuidePlan.failedAt(now)
            Log.w("EpgRepository", "archive guide failed channelId=${channel.id}: ${e.javaClass.simpleName}")
            0
        }
        stored
    }

    /** Identifies the current set of usable cache files, so a new/refreshed guide invalidates a skip. */
    private fun cacheFingerprint(): String {
        val now = System.currentTimeMillis()
        return context.cacheDir.listFiles()
            ?.filter { isUsableEpgCache(it.name, it.length(), it.lastModified(), now, CACHE_TTL_MS) }
            ?.sortedBy { it.name }
            ?.joinToString(",") { "${it.name}:${it.length()}:${it.lastModified()}" }
            .orEmpty()
    }

    /** An InputStream that mirrors every byte it reads into [out] — lets us parse a download while caching it. */
    private class TeeInputStream(
        private val src: java.io.InputStream,
        private val out: java.io.OutputStream,
    ) : java.io.InputStream() {
        override fun read(): Int { val b = src.read(); if (b >= 0) out.write(b); return b }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = src.read(b, off, len); if (n > 0) out.write(b, off, n); return n
        }
        override fun close() = src.close() // the caller owns [out] (closed by its own use{})
    }

    /** Drop a removed EPG source's stored programmes. */
    suspend fun clear(storeId: Long) = withContext(Dispatchers.IO) {
        epgDao.clearSource(storeId)
        epgDao.clearChannelsForSource(storeId)
    }

    companion object {
        /**
         * How a Stalker portal's own guide is addressed where a URL is expected. Not a real scheme and
         * never fetched: the EPG machinery — the sources list, the sync worker, the staleness check,
         * the error line — is all keyed by a source's URL, so giving the portal guide one lets it reuse
         * every bit of that instead of growing a parallel path with its own screen and its own bugs.
         */
        private const val STALKER_GUIDE_SCHEME = "stalker://"

        fun stalkerGuideUrl(sourceId: Long): String = "$STALKER_GUIDE_SCHEME$sourceId"

        /** The playlist id inside a [stalkerGuideUrl], or null when this is an ordinary feed URL. */
        fun stalkerSourceIdOf(url: String): Long? =
            url.takeIf { it.startsWith(STALKER_GUIDE_SCHEME) }?.removePrefix(STALKER_GUIDE_SCHEME)?.trim()?.toLongOrNull()

        // Keep up to ~7 days of just-aired programmes so the Guide can browse a long catch-up archive
        // (still bounded, and ultimately limited by how much past data the EPG feed actually provides —
        // many xmltv.php feeds only return 1–2 days of past programmes, so storage rarely reaches 7 days).
        private const val WINDOW_BACK_MS = 7L * 24 * 60 * 60 * 1000

        /**
         * How much finished guide a channel that cannot replay it keeps.
         *
         * It exists for the player overlay's "Before" slot and for a programme that has only just
         * ended, so it needs to cover a long film and nothing more. Everything past this is history
         * no user of that channel has any way to watch.
         */
        private const val RECENT_PAST_MS = 6L * 60 * 60 * 1000
        // WINDOW_AHEAD_MS used to be a hard-coded 48h here. It is now [SettingsRepository.guideDaysToKeep],
        // because two days was throwing away most of what providers actually send: the grid could only
        // scroll two days, and two days after a sync the guide was empty. See [guideAheadMs].
        private const val QUERY_CHUNK = 500
        private const val UPSERT_PROGRAMME_SQL =
            "INSERT OR REPLACE INTO `epg_programmes` (`id`,`sourceId`,`epgChannelId`,`startMs`,`stopMs`,`title`,`description`," +
                "`contentHash`,`categories`,`year`,`rating`,`lengthMin`,`episode`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?)"
        private const val CACHE_TTL_MS = 24L * 60 * 60 * 1000 // reuse a cached XMLTV for incremental matches up to 24h
        private const val PROGRESS_PROGRAMME_STEP = 500
        private const val EPG_DOWNLOAD_ATTEMPTS = 3

        // Upper bound on programme (id, hash) entries kept in memory during an incremental EPG sync.
        // ~20 bytes a tracked programme (ProgrammeHashTracker's primitive arrays), so 400k is ≈8 MB —
        // the same heap the old 100k boxed cap took. Channels beyond it fall back to write-through
        // (correct via the natural-key unique index + REPLACE), losing skip-unchanged for this run.
        private const val MAX_TRACKED_PROGRAMMES = 400_000
    }
}

/** Decision for one parsed programme, from [ProgrammeHashTracker.observe]. */
private sealed interface ProgrammeDecision {
    data object New : ProgrammeDecision
    data class Changed(val id: Long) : ProgrammeDecision
    data object Unchanged : ProgrammeDecision
    data object WriteThrough : ProgrammeDecision
}

/**
 * Memory-bounded replacement for the old whole-source programme hash map. Hashes are loaded lazily
 * per EPG channel (an indexed point query on the natural key) and only while the total entry count
 * stays under [maxEntries]; channels first seen after that are handled write-through. For a fresh
 * source nothing is loaded — the per-channel state only dedupes repeats inside the feed itself.
 *
 * Stored rows are kept as three primitive arrays per channel, sorted by start time (≈20 bytes a
 * programme). The old boxed `HashMap<Long, Pair<Long, Int>>` cost ≈100, which is why the cap had to
 * be 100,000 — and a 135,000-programme guide then rewrote everything past the cap on every sync.
 */
private class ProgrammeHashTracker(
    private val dao: tv.own.owntv.core.database.dao.EpgDao,
    private val sourceId: Long,
    private val freshSource: Boolean,
    private val maxEntries: Int,
) {
    /** One channel's stored rows (sorted by start) plus what this run has seen and added. */
    private class ChannelState(val starts: LongArray, val ids: LongArray, val hashes: IntArray) {
        val seen = BooleanArray(starts.size)
        /** Start times first met in this run (new rows) — a repeat of one is the feed's own duplicate. */
        val added = HashSet<Long>()
        /** The feed delivered at least one programme for this channel this run. */
        var reached = false
    }

    private val byChannel = HashMap<String, ChannelState>()
    private val untrackedChannels = HashSet<String>()
    private var entries = 0
    var overflowed = false
        private set

    /**
     * Loads the source's stored rows in one ordered read, straight into the per-channel arrays.
     * Asking channel by channel as the feed reaches each one was thousands of queries — on a TV about
     * ten seconds of a re-sync. Stops before [maxEntries]; a channel it did not reach is still loaded
     * on its own by [observe].
     */
    suspend fun preload(db: tv.own.owntv.core.database.OwnTVDatabase) {
        if (freshSource) return
        db.useReaderConnection { connection ->
            connection.usePrepared(
                "SELECT epgChannelId, startMs, id, contentHash FROM epg_programmes WHERE sourceId = ? ORDER BY epgChannelId, startMs",
            ) { statement ->
                statement.bindLong(1, sourceId)
                var channel: String? = null
                var starts = LongArray(64)
                var ids = LongArray(64)
                var hashes = IntArray(64)
                var n = 0
                fun flush() {
                    val key = channel ?: return
                    byChannel[key] = ChannelState(starts.copyOf(n), ids.copyOf(n), hashes.copyOf(n))
                    entries += n
                    n = 0
                }
                while (statement.step()) {
                    val key = statement.getText(0)
                    if (key != channel) {
                        flush()
                        if (entries >= maxEntries) return@usePrepared
                        channel = key
                    }
                    if (n == starts.size) {
                        starts = starts.copyOf(n * 2)
                        ids = ids.copyOf(n * 2)
                        hashes = hashes.copyOf(n * 2)
                    }
                    starts[n] = statement.getLong(1)
                    ids[n] = statement.getLong(2)
                    hashes[n] = statement.getLong(3).toInt()
                    n++
                }
                flush()
            }
        }
    }

    suspend fun observe(channel: String, startMs: Long, hash: Int): ProgrammeDecision {
        if (channel in untrackedChannels) return ProgrammeDecision.WriteThrough
        val state = byChannel[channel] ?: run {
            if (entries >= maxEntries) {
                untrackedChannels.add(channel)
                if (!overflowed) {
                    overflowed = true
                    Log.w("EpgRepository", "EPG hash tracker cap ($maxEntries) reached for sourceId=$sourceId — further channels sync write-through")
                }
                return ProgrammeDecision.WriteThrough
            }
            val rows = if (freshSource) emptyList() else dao.epgHashesForChannel(sourceId, channel).sortedBy { it.startMs }
            ChannelState(
                LongArray(rows.size) { rows[it].startMs },
                LongArray(rows.size) { rows[it].id },
                IntArray(rows.size) { rows[it].contentHash },
            ).also {
                entries += rows.size
                byChannel[channel] = it
            }
        }
        state.reached = true
        // A second programme at the same start on the same channel in THIS feed (feeds list e.g.
        // "Mass" and "Live: Mass" at one start time): the first wins. Letting the later one overwrite
        // it made the stored row alternate between the two, so it was rewritten on every sync.
        val i = state.starts.binarySearch(startMs)
        if (i < 0) {
            if (!state.added.add(startMs)) return ProgrammeDecision.Unchanged
            entries++
            return ProgrammeDecision.New
        }
        if (state.seen[i]) return ProgrammeDecision.Unchanged
        state.seen[i] = true
        return if (state.hashes[i] == hash) ProgrammeDecision.Unchanged else ProgrammeDecision.Changed(state.ids[i])
    }

    /**
     * Row ids of tracked programmes that existed before this run but never appeared in the feed. Only
     * channels the feed reached: a preloaded channel it sent nothing for keeps its guide, as it did when
     * channels were only loaded on arrival.
     */
    fun staleTrackedIds(): List<Long> {
        if (freshSource) return emptyList()
        val stale = ArrayList<Long>()
        for (state in byChannel.values) {
            if (!state.reached) continue
            for (i in state.starts.indices) if (!state.seen[i]) stale.add(state.ids[i])
        }
        return stale
    }
}

/**
 * Split a stored guide address into the feeds it actually names. Commas are legal inside a URL, so a
 * value is only treated as a list when every part is itself an absolute http(s) address — which also
 * keeps the Stalker portal marker URL intact. Whitespace is trimmed and duplicates dropped.
 */
fun splitGuideUrls(raw: String?): List<String> {
    val url = raw?.trim()?.takeIf { it.isNotBlank() } ?: return emptyList()
    if (',' !in url) return listOf(url)
    val parts = url.split(',').map { it.trim() }
    if (parts.any { !it.startsWith("http://", true) && !it.startsWith("https://", true) }) return listOf(url)
    return parts.distinct()
}
