package tv.own.owntv.player

import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import tv.own.owntv.core.settings.LiveBuffer
import tv.own.owntv.core.stalker.ReconnectUrlProvider

/** Everything a live tune hands an engine besides the URL. */
data class LiveRequest(
    val meta: MediaMeta,
    val userAgent: String?,
    val prerollSecs: Int?,
    val liveBuffer: LiveBuffer.Override?,
    val httpHeaders: String?,
    val drmConfig: String?,
    val manifestType: String?,
    val directSource: String?,
)

/**
 * Why a live engine let a channel go. [text] is for the log only; the ladder reads [httpStatus], so a
 * reworded sentence cannot change what it learns.
 */
data class HandOver(val text: String, val httpStatus: Int? = null) {
    /** The panel refused the *request* (busy, forbidden, rate-limited): nothing about the format. */
    val refused: Boolean get() = httpStatus?.let { LiveStreamQuirks.isRequestRefusal(it) } == true

    companion object {
        /** A failure the engine reported; [detail] is the engine's own error text, which may name the
         *  provider's HTTP status. Only [detail] is read for it, never the sentence around it. */
        fun engineError(text: String, detail: String?): HandOver =
            HandOver("$text: $detail", detail?.let { PlayerErrors.httpStatusIn(it) })
    }
}

/** What mpv did with a channel it was just given: playback started, or an error. */
data class MpvOutcome(val opened: Boolean, val error: String?)

/**
 * mpv's outcome from its two signals, or null while it is still opening. An error wins. Nothing else
 * counts as "opened" — the spinner is not raised by a normal load, so "not buffering" was true from the
 * first instant and every mpv tune read as opened before a byte had arrived.
 */
internal fun mpvOutcomeOf(playbackStarted: Boolean, error: PlaybackFailure?): MpvOutcome? = when {
    error != null -> MpvOutcome(opened = false, error = error.toString())
    playbackStarted -> MpvOutcome(opened = true, error = null)
    else -> null
}

/**
 * The two live engines, as [LiveTuneController] drives them.
 *
 * Exactly the operations the controller uses and nothing more. It exists so the controller's
 * sequencing — superseding tunes, the ladder, the give-up alarm — can be unit-tested against a fake;
 * production is [EnginePair], a thin pass-through to the real engines.
 */
interface LiveEngines {
    /** What ExoPlayer holds right now, or null. */
    val exoUrl: String?
    val exoIsHls: Boolean
    val exoFailed: Boolean
    /** ExoPlayer is working through its own reconnects after having played (see [LivePreviewEngine.stillReconnecting]). */
    val exoStillReconnecting: Boolean get() = false
    /** ExoPlayer cannot play this stream's content (see [LivePreviewEngine.contentBroken]). */
    val exoContentBroken: Boolean get() = false
    /** Whether mpv holds a stream (full-screen live, a film, a catch-up). */
    val mpvHasStream: Boolean

    fun exoPlay(url: String, muted: Boolean, request: LiveRequest)
    fun exoSetMuted(muted: Boolean)
    fun exoStop()
    fun exoReleaseUhdDecoder()
    fun exoAbandon(reason: String)

    /** Run [LiveExoWatchdog] on ExoPlayer until the outcome is settled. */
    suspend fun watchExo(
        channelName: String,
        stillOurs: () -> Boolean,
        handOver: suspend (HandOver) -> Unit,
        onOpened: () -> Unit,
        postponeDeadline: (Long) -> Unit,
        log: (String) -> Unit,
    )

    fun mpvPlay(url: String, request: LiveRequest)
    fun mpvStop()
    suspend fun mpvStopAndAwaitRelease()
    fun mpvAbandon(reason: String)

    /**
     * Wait up to [timeoutMs] for mpv to open or fail; null when it did neither.
     *
     * **"Opened" is playback moving — [OwnTVPlayer.playbackStarted], never `isPlaying` or the spinner.**
     * mpv seeds `isPlaying` true at load time and never raises the spinner on a normal load, so neither
     * says anything about whether the stream ever arrived.
     */
    suspend fun awaitMpvOutcome(timeoutMs: Long): MpvOutcome?

    /**
     * After mpv has opened: wait until it fails for good, and say why. "No internet" does not count — mpv
     * reconnects by itself when the network returns, and the other engine could not play without one either.
     */
    suspend fun awaitMpvFailure(): String

    /** The Stalker re-resolve hook, installed on both engines, or cleared with null. */
    fun setReconnectProvider(provider: ReconnectUrlProvider?)

    /** How far into its current stream the live engine on screen is — for a saved copy's clock. */
    fun positionMs(onExo: Boolean): Long = 0L
}

/** Start [url] on a live ExoPlayer engine with everything [request] carries — a tune, or a Multiview tile. */
internal fun LivePreviewEngine.play(url: String, muted: Boolean, request: LiveRequest) = play(
    url,
    muted = muted,
    meta = request.meta,
    userAgent = request.userAgent,
    prerollSecsOverride = request.prerollSecs,
    liveBufferOverride = request.liveBuffer,
    httpHeaders = request.httpHeaders,
    drmConfig = request.drmConfig,
    manifestType = request.manifestType,
    directSource = request.directSource,
)

/** The real engines: the live ExoPlayer engine and the process-wide mpv player. */
class EnginePair(private val exo: LivePreviewEngine, private val mpv: OwnTVPlayer) : LiveEngines {
    override val exoUrl: String? get() = exo.currentUrl
    override val exoIsHls: Boolean get() = exo.isHlsStream
    override val exoFailed: Boolean get() = exo.state.value == LivePreviewEngine.State.ERROR
    override val exoStillReconnecting: Boolean get() = exo.stillReconnecting
    override val exoContentBroken: Boolean get() = exo.contentBroken
    override val mpvHasStream: Boolean get() = mpv.hasActiveStream

    override fun exoPlay(url: String, muted: Boolean, request: LiveRequest) = exo.play(url, muted, request)

    override fun exoSetMuted(muted: Boolean) = exo.setMuted(muted)
    override fun exoStop() = exo.stop()
    override fun exoReleaseUhdDecoder() = exo.releaseDecoderForUhd()
    override fun exoAbandon(reason: String) { exo.abandon(reason) }

    override suspend fun watchExo(
        channelName: String,
        stillOurs: () -> Boolean,
        handOver: suspend (HandOver) -> Unit,
        onOpened: () -> Unit,
        postponeDeadline: (Long) -> Unit,
        log: (String) -> Unit,
    ) {
        LiveExoWatchdog(exo, stillOurs, handOver, onOpened, postponeDeadline, log).watch(channelName)
    }

    override fun mpvPlay(url: String, request: LiveRequest) = mpv.play(
        url = url,
        title = request.meta.title,
        subtitle = request.meta.subtitle,
        logoUrl = request.meta.logoUrl,
        isLive = true,
        muted = false,
        userAgent = request.userAgent,
        httpHeaders = request.httpHeaders,
        // The same stable key ExoPlayer files this channel under, so a zoom or volume set on one
        // engine is not forgotten when the channel falls back to the other.
        contentKey = request.meta.contentKey,
        livePrerollSecsOverride = request.prerollSecs,
        liveBufferOverride = request.liveBuffer,
    )

    override fun mpvStop() = mpv.stop()
    override suspend fun mpvStopAndAwaitRelease() { mpv.stopAndAwaitRelease() }
    override fun mpvAbandon(reason: String) = mpv.abandonLive(reason)

    override suspend fun awaitMpvOutcome(timeoutMs: Long): MpvOutcome? = withTimeoutOrNull(timeoutMs) {
        combine(mpv.playbackStarted, mpv.error, ::mpvOutcomeOf).first { it != null }
    }

    override suspend fun awaitMpvFailure(): String =
        mpv.error.first { it != null && it != PlaybackFailure.NoInternet }.toString()

    override fun setReconnectProvider(provider: ReconnectUrlProvider?) {
        exo.reconnectUrlProvider = provider
        mpv.reconnectUrlProvider = provider
    }

    override fun positionMs(onExo: Boolean): Long = if (onExo) exo.livePositionMs() else mpv.position.value
}
